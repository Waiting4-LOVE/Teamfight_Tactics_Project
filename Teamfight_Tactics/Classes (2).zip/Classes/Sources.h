#ifndef __MW_CPP_RESOURCE_H__
#define __MW_CPP_RESOURCE_H__
#include <string>

static const std::string startgame_png = "startgame.png";
#endif//   __MW_CPP_RESOURCE_H__
