#pragma once
#include "Equipment.h"
#include "cocos2d.h"
USING_NS_CC;

class tearsOfTheGoddess :public Equipment{
public:
	CREATE_FUNC(tearsOfTheGoddess);
	static tearsOfTheGoddess* createTearsOfTheGoddess();
};

