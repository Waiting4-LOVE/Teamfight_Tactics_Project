#ifndef __DEFINITION_H__
#define __DEFINITION_H__

#define DISPLAY_TIME_INIT_SCENE 2
#define TRANSITION_TIME 0.5

#endif // __DEFINITION_H__